package main

import (
 "bytes"
 "context"
 "crypto/rand"
 "crypto/rsa"
 "crypto/x509"
 "crypto/x509/pkix"
 "encoding/json"
 "encoding/pem"
 "fmt"
 "io"
 "log"
 "math/big"
 "net/http"
 "os"
 "strings"
 "sync"
 "sync/atomic"
 "time"

 ws "github.com/coder/websocket"
 "github.com/klauspost/compress/zstd"
 "github.com/tidwall/gjson"
)

func must(err error) { if err != nil { log.Fatal(err) } }
func check(ok bool, msg string) { if !ok { log.Fatal(msg) } }
var next atomic.Int64
var recordMu sync.Mutex
func record(r *http.Request, body []byte) {
 recordMu.Lock(); defer recordMu.Unlock()
 f, err := os.OpenFile("/out/wire.jsonl", os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644); must(err); defer f.Close()
 must(json.NewEncoder(f).Encode(map[string]any{"body":json.RawMessage(body), "session":r.Header.Get("Session-Id"), "thread":r.Header.Get("Thread-Id"), "version":r.Header.Get("Version"), "account":r.Header.Get("ChatGPT-Account-ID"), "ws":r.Header.Get("Upgrade")=="websocket"}))
}
func completed(id string) []byte { return []byte(fmt.Sprintf(`{"type":"response.completed","response":{"id":%q,"object":"response","model":"gpt-5.6-sol","status":"completed","output":[{"type":"message","id":"msg_local_output","role":"assistant","status":"completed","content":[{"type":"output_text","text":"local mock answer","annotations":[]}]}],"usage":{"input_tokens":100,"output_tokens":10,"total_tokens":110,"input_tokens_details":{"cached_tokens":40}}}}`, id)) }
func serve() {
 h := http.HandlerFunc(func(w http.ResponseWriter,r *http.Request){
  if r.URL.Path != "/backend-api/codex/responses" { http.Error(w,"local mock only",404); return }
  if !strings.HasPrefix(r.Header.Get("Authorization"),"Bearer fake-local-") { http.Error(w,"unexpected test credential",401); return }
  if strings.EqualFold(r.Header.Get("Upgrade"),"websocket") {
   c,err:=ws.Accept(w,r,nil); if err!=nil{return}; defer c.CloseNow(); c.SetReadLimit(16<<20)
   ctx:=context.Background()
   for {
    _,body,err:=c.Read(ctx); if err!=nil{return}; record(r,body)
    id:=fmt.Sprintf("resp_local_%d",next.Add(1))
    must(c.Write(ctx,ws.MessageText,[]byte(fmt.Sprintf(`{"type":"response.created","response":{"id":%q,"status":"in_progress"}}`,id))))
    if strings.Contains(string(body),"please hold") {
     must(c.Write(ctx,ws.MessageText,[]byte(`{"type":"response.output_text.delta","delta":"partial"}`)))
     _,control,err:=c.Read(ctx); if err!=nil{return}; record(r,control)
     if gjson.GetBytes(control,"type").String()!="response.interrupt" {return}
     must(c.Write(ctx,ws.MessageText,[]byte(fmt.Sprintf(`{"type":"response.interrupt.accepted","response_id":%q}`,id))))
    }
    must(c.Write(ctx,ws.MessageText,completed(id)))
   }
  }
  var reader io.Reader=r.Body
  if r.Header.Get("Content-Encoding")=="zstd" { d,err:=zstd.NewReader(r.Body); must(err); defer d.Close();reader=d }
  body,err:=io.ReadAll(reader); must(err); record(r,body)
  id:=fmt.Sprintf("resp_local_%d",next.Add(1))
  w.Header().Set("Content-Type","text/event-stream");w.Header().Set("X-Request-ID",id)
  fmt.Fprintf(w,"data: %s\n\ndata: [DONE]\n\n",completed(id))
 })
 log.Fatal(http.ListenAndServeTLS("127.0.0.1:443","/out/cert.pem","/out/key.pem",h))
}
func cert() {
 key,err:=rsa.GenerateKey(rand.Reader,2048);must(err)
 tpl:= &x509.Certificate{SerialNumber:big.NewInt(164),Subject:pkix.Name{CommonName:"local Codex probe"},NotBefore:time.Now().Add(-time.Hour),NotAfter:time.Now().Add(48*time.Hour),DNSNames:[]string{"chatgpt.com"},KeyUsage:x509.KeyUsageDigitalSignature|x509.KeyUsageKeyEncipherment|x509.KeyUsageCertSign,ExtKeyUsage:[]x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},BasicConstraintsValid:true,IsCA:true}
 der,err:=x509.CreateCertificate(rand.Reader,tpl,tpl,&key.PublicKey,key);must(err)
 must(os.WriteFile("/out/cert.pem",pem.EncodeToMemory(&pem.Block{Type:"CERTIFICATE",Bytes:der}),0644))
 must(os.WriteFile("/out/key.pem",pem.EncodeToMemory(&pem.Block{Type:"RSA PRIVATE KEY",Bytes:x509.MarshalPKCS1PrivateKey(key)}),0600))
}
func payload(previous, text string) []byte {
 p:=map[string]any{"model":"gpt-5.6-sol","stream":true,"instructions":"Stable local guidance <tag>","tools":[]any{map[string]any{"type":"function","name":"inspect_local","description":"Local only","parameters":map[string]any{"type":"object","properties":map[string]any{}}}},"input":[]any{map[string]any{"role":"user","content":"first local question"}},"prompt_cache_key":"local-stable-session","client_metadata":map[string]any{"ws_request_header_x_openai_internal_codex_responses_lite":"true"}}
 if previous!="" {p["previous_response_id"]=previous;p["input"]=append(p["input"].([]any),map[string]any{"role":"assistant","content":"local mock answer"},map[string]any{"role":"user","content":text})}
 b,err:=json.Marshal(p);must(err);return b
}
func headers(key string) http.Header {return http.Header{"Authorization":{"Bearer "+key},"Content-Type":{"application/json"},"X-OpenAI-Internal-Codex-Responses-Lite":{"true"},"Session-Id":{"local-stable-session"},"Thread-Id":{"local-stable-thread"}}}
func request(key string,b []byte) (int,[]byte) {
 req,err:=http.NewRequest("POST","http://127.0.0.1:8080/v1/responses",bytes.NewReader(b));must(err);req.Header=headers(key)
 c:=&http.Client{Timeout:15*time.Second};res,err:=c.Do(req);must(err);defer res.Body.Close();raw,err:=io.ReadAll(res.Body);must(err);return res.StatusCode,raw
}
func probe() {
 status,b:=request("sk-invalid-local",payload("",""));check(status==401||status==403,fmt.Sprintf("invalid auth: %d %s",status,b))
 status,b=request("sk-local-empty-164",payload("",""));check(status==403&&bytes.Contains(b,[]byte("INSUFFICIENT_BALANCE")),fmt.Sprintf("empty balance: %d %s",status,b))
 denyCtx,denyCancel:=context.WithTimeout(context.Background(),5*time.Second);defer denyCancel()
 for _,key:=range []string{"sk-invalid-local","sk-local-empty-164"} {
  c,res,err:=ws.Dial(denyCtx,"ws://127.0.0.1:8080/v1/responses",&ws.DialOptions{HTTPHeader:headers(key)})
  check(err!=nil&&c==nil&&res!=nil&&(res.StatusCode==401||res.StatusCode==403),"WS denied caller was accepted")
 }
 for _,previous:=range []string{"","","resp_local_1","resp_local_2"} {
  p:=payload(previous,"continue local history"); var history map[string]any; must(json.Unmarshal(p,&history)); delete(history,"previous_response_id"); p,err:=json.Marshal(history);must(err); status,b=request("sk-local-http-164",p);check(status==200&&bytes.Contains(b,[]byte("response.completed")),fmt.Sprintf("HTTP request: %d %s",status,b))
 }
 ctx,cancel:=context.WithTimeout(context.Background(),45*time.Second);defer cancel()
 for i:=0;i<3;i++ {
  c,_,err:=ws.Dial(ctx,"ws://127.0.0.1:8080/v1/responses",&ws.DialOptions{HTTPHeader:headers("sk-local-ws-164")});must(err)
  p:=payload("","");if i==1 {p=payload("resp_local_5","continue after reconnect")}
  var m map[string]any;must(json.Unmarshal(p,&m));m["type"]="response.create"
  if i==2 {m["input"]=[]any{map[string]any{"role":"user","content":"please hold"}}}
  p,err=json.Marshal(m);must(err);must(c.Write(ctx,ws.MessageText,p))
  var id string;ack:=false
  for { _,event,err:=c.Read(ctx);must(err);kind:=gjson.GetBytes(event,"type").String()
   if kind=="error"||kind=="response.failed" {log.Fatal(string(event))}
   if kind=="response.created" {id=gjson.GetBytes(event,"response.id").String()}
   if kind=="response.output_text.delta"&&i==2 {must(c.Write(ctx,ws.MessageText,[]byte(fmt.Sprintf(`{"type":"response.interrupt","response_id":%q,"mode":"discard_partial_items"}`,id))))}
   if kind=="response.interrupt.accepted" {ack=true}
   if kind=="response.completed" {break}
  }
  if i==2 {check(ack,"interrupt acknowledgement absent")
   p=payload(id,"continue after interrupt");must(json.Unmarshal(p,&m));m["type"]="response.create";p,err=json.Marshal(m);must(err);must(c.Write(ctx,ws.MessageText,p))
   for {_,event,err:=c.Read(ctx);must(err);if gjson.GetBytes(event,"type").String()=="response.completed" {break};check(gjson.GetBytes(event,"type").String()!="error",string(event))}
  }
  must(c.Close(ws.StatusNormalClosure,"local probe done"))
 }
 fmt.Println("PASS: invalid auth rejected; four HTTP generations; WS reconnect, interrupt and continuation (four generations)")
}
func main(){switch os.Args[1] {case "cert":cert();case "serve":serve();case "probe":probe();default:panic("unknown probe mode")}}
