import json
from decimal import Decimal
from pathlib import Path
p=Path(__file__).parent
wire=[json.loads(x) for x in (p/'wire.jsonl').read_text().splitlines()]
creates=[r for r in wire if r['body'].get('type')!='response.interrupt']
assert len(creates)==8
assert len(wire)==9
summary={}
for transport in (False, True):
 rows=[r for r in creates if r['ws']==transport]
 assert len(rows)==4
 prefixes=[]
 for r in rows:
  b=r['body']
  assert r['version']=='0.164.0'
  assert 'instructions' not in b and 'tools' not in b
  prefix=b['input'][:2]
  assert [item['type'] for item in prefix]==['additional_tools','message']
  assert prefix[0]['id'].startswith('at_') and prefix[1]['id'].startswith('msg_')
  assert prefix[1]['content'][0]['text']=='Stable local guidance <tag>'
  prefixes.append(prefix)
 assert all(prefix==prefixes[0] for prefix in prefixes)
 assert len({r['body']['client_metadata']['thread_id'] for r in rows})==1
 assert len({r['body']['prompt_cache_key'] for r in rows})==1
 summary['ws' if transport else 'http']={'generations':4,'prefix_equal_across_requests':True,'prefix_ids':[item['id'] for item in prefixes[0]],'stable_thread':True,'stable_prompt_cache_key':True}
usage=[json.loads(x,parse_float=Decimal) for x in (p/'usage.jsonl').read_text().splitlines()]
assert {r['account_id'] for r in usage}=={164,165}
for r in usage:
 assert (r['count'],r['input_tokens'],r['output_tokens'],r['cached_tokens'])==(4,240,40,160)
 assert r['actual_cost']>0
balance=json.loads((p/'balance.json').read_text(),parse_float=Decimal)
assert Decimal(100)-balance['balance']==sum(r['actual_cost'] for r in usage)
assert balance['frozen_balance']==0
assert (p/'rollback-usage-count.txt').read_text().strip()=='8'
state=json.loads((p/'candidate-exit.json').read_text())
assert state['ExitCode']==0 and not state['OOMKilled']
summary.update({'authorized_real_accounts_used':False,'upstream':'local TLS mock only','invalid_auth_rejected':True,'zero_balance_rejected':True,'http_and_ws_auth_checks':True,'disabled_account_selected':False,'interrupt_billed_once':True,'usage_rows':8,'billing_balanced':True,'mock_cached_tokens_per_generation':40,'real_cache_tested':False,'candidate_exit_code':0,'baseline_restart_retained_usage_rows':8})
(p/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
print('PASS: stable tools/instruction prefixes, account selection, exactly-once usage, balanced test charges, clean candidate exit and baseline rollback')
