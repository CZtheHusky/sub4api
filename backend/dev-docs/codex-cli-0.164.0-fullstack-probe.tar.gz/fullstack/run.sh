#!/bin/bash
set -euo pipefail
root=/tmp/codex164-alignment.ymc5RW/fullstack
rm -f "$root/cert.pem" "$root/key.pem" "$root/wire.jsonl"
pg=codex164-local-pg
redis=codex164-local-redis
app=codex164-local-app
mock=codex164-local-mock
cleanup() {
 for c in "$app" "$mock" "$redis" "$pg"; do
  docker logs "$c" > "$root/$c.log" 2>&1 || true
  docker rm -fv "$c" >/dev/null 2>&1 || true
 done
}
trap cleanup EXIT
trap 'exit 143' TERM
# All resources are new, contain test data only, and expose no host ports.
docker run -d --name "$pg" --network none --memory 1g --cpus 1 -e POSTGRES_PASSWORD=local-probe-only -e POSTGRES_DB=sub4api_probe postgres:18-alpine > "$root/postgres-container.id"
docker run -d --name "$redis" --network "container:$pg" --memory 256m --cpus 1 redis:8-alpine > "$root/redis-container.id"
for i in $(seq 1 60); do if docker exec "$pg" pg_isready -U postgres >/dev/null; then break; fi; sleep 1; done
/bin/bash /tmp/codex164-alignment.ymc5RW/isolated-build.sh build -p 2 -o /tmp/task/fullstack/probe /tmp/task/fullstack/probe.go
docker run --rm --user "$(id -u):$(id -g)" --network none -v "$root:/out" redis:8-alpine /out/probe cert
docker run -d --user "$(id -u):$(id -g)" --name "$mock" --network "container:$pg" --memory 256m --cpus 1 -v "$root:/out" redis:8-alpine /out/probe serve > "$root/mock-container.id"
start_app() {
 docker run -d --name "$app" --network "container:$pg" --memory 2g --cpus 2 \
 -v "$root:/out" --tmpfs /app/data --workdir /app \
 -e AUTO_SETUP=true -e DATA_DIR=/app/data -e DATABASE_HOST=127.0.0.1 -e DATABASE_PORT=5432 \
 -e DATABASE_USER=postgres -e DATABASE_PASSWORD=local-probe-only -e DATABASE_DBNAME=sub4api_probe \
 -e DATABASE_SSLMODE=disable -e REDIS_HOST=127.0.0.1 -e ADMIN_EMAIL=admin@example.invalid \
 -e ADMIN_PASSWORD=LocalProbeOnly164 -e JWT_SECRET=local-probe-only-164-abcdefghijklmnopqrstuvwxyz \
 -e SERVER_HOST=127.0.0.1 -e SSL_CERT_FILE=/out/cert.pem -e TZ=UTC \
 redis:8-alpine /bin/sh -c 'echo "127.0.0.1 chatgpt.com" >> /etc/hosts; exec "/out/$1"' sh "$1" > "$root/app-container.id"
 for i in $(seq 1 120); do
  if docker exec "$app" wget -qO- http://127.0.0.1:8080/health > "$root/$1-health.json" 2>/dev/null; then return; fi
  if [ "$(docker inspect --format '{{.State.Running}}' "$app")" != true ]; then docker logs "$app"; return 1; fi
  sleep 1
 done
 return 1
}
start_app baseline
docker exec -i "$pg" psql -v ON_ERROR_STOP=1 -U postgres -d sub4api_probe < "$root/seed.sql" > "$root/seed.log"
docker logs "$app" > "$root/baseline-initial.log" 2>&1
docker stop -t 15 "$app" >/dev/null
docker rm "$app" >/dev/null
start_app candidate
docker inspect --format '{{json .HostConfig.NetworkMode}} {{json .HostConfig.PortBindings}}' "$pg" "$redis" "$mock" "$app" > "$root/isolation.txt"
docker exec "$app" cat /proc/net/route >> "$root/isolation.txt"
docker exec "$app" /out/probe probe > "$root/probe.log" 2>&1
sleep 3
docker exec "$pg" psql -U postgres -d sub4api_probe -At -c 'SELECT row_to_json(t) FROM (SELECT account_id,count(*) AS count,sum(input_tokens) AS input_tokens,sum(output_tokens) AS output_tokens,sum(cache_read_tokens) AS cached_tokens,sum(actual_cost) AS actual_cost FROM usage_logs GROUP BY account_id ORDER BY account_id) t' > "$root/usage.jsonl"
docker exec "$pg" psql -U postgres -d sub4api_probe -At -c 'SELECT row_to_json(t) FROM (SELECT balance,frozen_balance FROM users WHERE id=164) t' > "$root/balance.json"
docker logs "$app" > "$root/candidate.log" 2>&1
docker stop -t 15 "$app" > "$root/candidate-stop.txt"
docker inspect --format '{{json .State}}' "$app" > "$root/candidate-exit.json"
docker rm "$app" >/dev/null
start_app baseline
docker exec "$pg" psql -U postgres -d sub4api_probe -At -c 'SELECT count(*) FROM usage_logs' > "$root/rollback-usage-count.txt"
docker logs "$app" > "$root/baseline-rollback.log" 2>&1
printf 'PASS: baseline bootstrap -> candidate requests -> baseline restart on the same temporary database\n'

/usr/bin/python3 "$root/validate.py"
