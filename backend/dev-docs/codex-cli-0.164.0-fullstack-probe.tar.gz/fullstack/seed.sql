INSERT INTO users(id,email,password_hash,balance) VALUES(164,'local-probe@example.invalid','not-a-login-password',100);
INSERT INTO groups(id,name,platform) VALUES(164,'local-http','openai'),(165,'local-ws','openai');
INSERT INTO api_keys(id,user_id,key,name,group_id) VALUES(164,164,'sk-local-http-164','local-http',164),(165,164,'sk-local-ws-164','local-ws',165);
INSERT INTO accounts(id,name,platform,type,credentials,extra,priority) VALUES
 (164,'local-http','openai','oauth','{"access_token":"fake-local-http-token","chatgpt_account_id":"fake-local-http-account"}','{"openai_oauth_responses_websockets_v2_mode":"off"}',50),
 (165,'local-ws','openai','oauth','{"access_token":"fake-local-ws-token","chatgpt_account_id":"fake-local-ws-account"}','{"openai_oauth_responses_websockets_v2_mode":"ctx_pool"}',50),
 (166,'disabled-candidate','openai','oauth','{"access_token":"fake-local-disabled","chatgpt_account_id":"fake-local-disabled"}','{}',1);
UPDATE accounts SET status='disabled' WHERE id=166;
INSERT INTO account_groups(account_id,group_id) VALUES(164,164),(165,165),(166,164),(166,165);

INSERT INTO users(id,email,password_hash,balance) VALUES(165,'empty-balance@example.invalid','not-a-login-password',0);
INSERT INTO api_keys(id,user_id,key,name,group_id) VALUES(166,165,'sk-local-empty-164','empty-balance',164);
