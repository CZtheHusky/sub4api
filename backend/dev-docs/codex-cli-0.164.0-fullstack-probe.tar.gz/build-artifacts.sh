#!/bin/bash
set -eu
/bin/bash /tmp/codex164-alignment.ymc5RW/isolated-build.sh build -p 2 -trimpath -ldflags="-s -w -X main.Version=local-codex164-candidate -X main.Commit=e59fb52e-dirty" -o /tmp/task/fullstack/candidate ./cmd/server
/bin/bash /tmp/codex164-alignment.ymc5RW/isolated-baseline-build.sh build -p 2 -trimpath -ldflags="-s -w -X main.Version=local-baseline-e59fb52e -X main.Commit=e59fb52e" -o /tmp/task/fullstack/baseline ./cmd/server
