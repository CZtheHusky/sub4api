package service

import (
	"context"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"strings"
	"testing"
	"time"

	"github.com/MACOS-DO/sub4api/internal/config"
	coderws "github.com/coder/websocket"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/require"
)

// Local probe only: overlay this test into the package inside the network sandbox.
func TestCodex164InstalledCLIViaGateway(t *testing.T) {
	gin.SetMode(gin.TestMode)
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Minute)
	defer cancel()
	gateway := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		port := strings.Split(r.URL.Path, "/")[2]
		conn, err := coderws.Accept(w, r, nil)
		if err != nil {
			t.Logf("accept: %v", err)
			return
		}
		defer conn.CloseNow()
		conn.SetReadLimit(16 << 20)
		_, first, err := conn.Read(ctx)
		if err != nil {
			t.Logf("first frame: %v", err)
			return
		}
		cfg := &config.Config{}
		cfg.Gateway.OpenAIWS.Enabled = true
		cfg.Gateway.OpenAIWS.OAuthEnabled = true
		cfg.Gateway.OpenAIWS.ResponsesWebsocketsV2 = true
		cfg.Gateway.OpenAIWS.MaxConnsPerAccount = 1
		cfg.Gateway.OpenAIWS.MaxIdlePerAccount = 1
		cfg.Gateway.OpenAIWS.DialTimeoutSeconds = 3
		cfg.Gateway.OpenAIWS.ReadTimeoutSeconds = 3
		cfg.Gateway.OpenAIWS.WriteTimeoutSeconds = 3
		pool := newOpenAIWSConnPool(cfg)
		pool.setClientDialerForTest(codexWireSocketDialer{url: "ws://127.0.0.1:" + port + "/v1/responses", inner: newDefaultOpenAIWSClientDialer()})
		defer pool.Close()
		svc := &OpenAIGatewayService{cfg: cfg, openaiWSPool: pool, cache: &stubGatewayCache{}, toolCorrector: NewCodexToolCorrector()}
		account := &Account{ID: 164, Platform: PlatformOpenAI, Type: AccountTypeOAuth, Concurrency: 1,
			Credentials: map[string]any{"access_token": "fake-local-token", "chatgpt_account_id": "fake-local-account"},
			Extra: map[string]any{"responses_websockets_v2_enabled": true}}
		c, _ := gin.CreateTestContext(httptest.NewRecorder())
		c.Request = r
		err = svc.ProxyResponsesWebSocketFromClient(ctx, c, conn, account, "fake-local-token", first, nil)
		if err != nil {
			t.Logf("gateway session ended: %v", err)
		}
	}))
	defer gateway.Close()
	command := exec.CommandContext(ctx, "/usr/bin/python3", "/tmp/task/cli-ws-probe.py")
	command.Env = append(os.Environ(), "CODEX_PROBE_GATEWAY_URL="+gateway.URL)
	output, err := command.CombinedOutput()
	t.Log(string(output))
	require.NoError(t, err)
}
