#!/bin/bash
set -eu
exec /usr/bin/bwrap \
  --unshare-net --unshare-pid --unshare-ipc --unshare-uts \
  --ro-bind / / --tmpfs /home --tmpfs /root --tmpfs /run --tmpfs /tmp \
  --proc /proc --dev /dev \
  --ro-bind /home/caozhe/workspace/sub4api/backend /tmp/workspace \
  --ro-bind /home/caozhe/go/pkg/mod /tmp/modules \
  --ro-bind /home/caozhe/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.0.linux-amd64 /tmp/toolchain \
  --bind /home/caozhe/.cache/go-build /tmp/buildcache \
  --bind /tmp/codex164-alignment.ymc5RW /tmp/task \
  --ro-bind /home/caozhe/.codex/packages/standalone/releases/0.164.0-x86_64-unknown-linux-musl/bin /tmp/cli --clearenv --setenv PATH /tmp/toolchain/bin:/usr/bin:/bin \
  --setenv HOME /tmp/home --setenv GOROOT /tmp/toolchain \
  --setenv GOPATH /tmp/gopath --setenv GOMODCACHE /tmp/modules \
  --setenv GOCACHE /tmp/buildcache --setenv GOPROXY off --setenv GOSUMDB off \
  --setenv GOTOOLCHAIN local --setenv GOMAXPROCS 2 \
  --setenv CGO_ENABLED 1 --setenv TZ UTC --chdir /tmp/workspace \
  /tmp/toolchain/bin/go "$@"

