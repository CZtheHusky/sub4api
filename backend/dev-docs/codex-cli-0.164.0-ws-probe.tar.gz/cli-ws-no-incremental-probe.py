import asyncio
import json
import os
from pathlib import Path
import time

import websockets

VIA_GATEWAY = os.environ.get('CODEX_PROBE_GATEWAY_URL')
OUT = Path('/tmp/task/cli-ws-no-incremental-capture')
OUT.mkdir(exist_ok=True)


async def scenario(name):
    steering = name.startswith('steer_')
    controlled = steering or name == 'cancel'
    folder = OUT / name
    folder.mkdir(exist_ok=True)
    home = Path('/tmp/home') / name
    (home / '.codex').mkdir(parents=True, exist_ok=True)
    records = []
    notifications = []
    pending = {}
    changed = asyncio.Event()
    generated = asyncio.Event()
    creates = []
    prewarms = []
    interrupts = []
    connections = []
    clock_start = time.monotonic()

    def record(kind, **data):
        records.append(dict(kind=kind, elapsed=time.monotonic() - clock_start, **data))

    async def upstream(ws, path):
        connection = len(connections) + 1
        connections.append(connection)
        record('handshake', connection=connection, path=path, headers=list(ws.request_headers.raw_items()))

        async def send(event):
            record('server', connection=connection, body=event)
            await ws.send(json.dumps(event))

        async def complete(rid, text):
            item = {'type': 'message', 'id': 'msg_' + rid, 'role': 'assistant', 'status': 'completed',
                    'content': [{'type': 'output_text', 'text': text, 'annotations': []}]}
            await send({'type': 'response.output_item.added', 'output_index': 0,
                        'item': dict(item, status='in_progress', content=[])})
            await send({'type': 'response.content_part.added', 'item_id': item['id'], 'output_index': 0,
                        'content_index': 0, 'part': {'type': 'output_text', 'text': '', 'annotations': []}})
            await send({'type': 'response.output_text.delta', 'item_id': item['id'], 'output_index': 0,
                        'content_index': 0, 'delta': text})
            await send({'type': 'response.output_item.done', 'output_index': 0, 'item': item})
            await send({'type': 'response.completed', 'response': {'id': rid, 'status': 'completed',
                        'output': [item], 'usage': {'input_tokens': 7, 'output_tokens': 2, 'total_tokens': 9}}})

        try:
            async for raw in ws:
                body = json.loads(raw)
                record('client', connection=connection, raw=raw, body=body)
                if body['type'] == 'response.create':
                    if body.get('generate') is False:
                        prewarms.append(records[-1])
                        await send({'type': 'response.created', 'response': {'id': 'resp_prewarm', 'status': 'in_progress', 'output': []}})
                        await send({'type': 'response.completed', 'response': {'id': 'resp_prewarm', 'status': 'completed', 'output': [],
                                    'usage': {'input_tokens': 0, 'output_tokens': 0, 'total_tokens': 0}}})
                        continue
                    creates.append(records[-1])
                    rid = 'resp_' + name + '_' + str(len(creates))
                    if name == 'retry_after' and len(creates) == 1:
                        await send({'type': 'error', 'status': 503, 'error': {'type': 'server_error',
                                    'code': 'server_is_overloaded', 'message': 'local retry probe',
                                    'headers': {'retry-after': '1'}}})
                        continue
                    await send({'type': 'response.created', 'response': {'id': rid, 'status': 'in_progress', 'output': []}})
                    if controlled and len(creates) == 1:
                        await send({'type': 'response.output_item.added', 'output_index': 0,
                                    'item': {'type': 'message', 'id': 'msg_pending', 'role': 'assistant', 'status': 'in_progress', 'content': []}})
                        await send({'type': 'response.content_part.added', 'item_id': 'msg_pending', 'output_index': 0,
                                    'content_index': 0, 'part': {'type': 'output_text', 'text': '', 'annotations': []}})
                        await send({'type': 'response.output_text.delta', 'item_id': 'msg_pending', 'output_index': 0,
                                    'content_index': 0, 'delta': 'Pending local response.'})
                        generated.set()
                    else:
                        await complete(rid, 'Local WS verified.')
                elif body['type'] == 'response.interrupt':
                    interrupts.append(body)
                    ack = {'type': 'response.interrupt.accepted', 'response_id': body['response_id']}
                    if name == 'steer_ack_first':
                        await send(ack)
                    await complete(body['response_id'], 'Finished before interruption.')
                    if name == 'steer_completion_first':
                        await send(ack)
        except websockets.ConnectionClosed as exc:
            record('close', connection=connection, code=exc.code, reason=exc.reason)

    server = await websockets.serve(upstream, '127.0.0.1', 0, compression=None)
    port = server.sockets[0].getsockname()[1]
    cmd = ['/tmp/cli/codex', 'app-server', '--stdio']
    config = {
        'model': 'gpt-5.6-sol', 'model_provider': 'local_mock', 'features.incremental_tools': False,
        'model_providers.local_mock.name': 'Local restricted WS mock',
        'model_providers.local_mock.base_url': (f'{VIA_GATEWAY}/probe/{port}/v1' if VIA_GATEWAY else f'http://127.0.0.1:{port}/v1'),
        'model_providers.local_mock.wire_api': 'responses',
        'model_providers.local_mock.env_key': 'MOCK_API_KEY',
        'model_providers.local_mock.requires_openai_auth': False,
        'model_providers.local_mock.supports_websockets': True,
    }
    for key, value in config.items():
        cmd += ['-c', key + '=' + json.dumps(value)]
    env = dict(os.environ, HOME=str(home), CODEX_HOME=str(home / '.codex'), MOCK_API_KEY='fake-local-key', TERM='dumb')
    stderr = (folder / 'stderr.log').open('wb')
    proc = await asyncio.create_subprocess_exec(*cmd, cwd=home, env=env, stdin=asyncio.subprocess.PIPE,
                                              stdout=asyncio.subprocess.PIPE, stderr=stderr, limit=4*1024*1024)

    async def reader():
        while line := await proc.stdout.readline():
            message = json.loads(line)
            notifications.append(message)
            if 'id' in message and message['id'] in pending:
                pending.pop(message['id']).set_result(message)
            changed.set()

    reader_task = asyncio.create_task(reader())
    sequence = 0

    async def rpc(method, params):
        nonlocal sequence
        sequence += 1
        future = asyncio.get_running_loop().create_future()
        pending[sequence] = future
        proc.stdin.write((json.dumps({'id': sequence, 'method': method, 'params': params}) + '\n').encode())
        await proc.stdin.drain()
        result = await asyncio.wait_for(future, 15)
        assert 'error' not in result, result
        return result['result']

    async def completed(turn):
        while True:
            changed.clear()
            for message in notifications:
                if message.get('method') == 'turn/completed' and message['params']['turn']['id'] == turn:
                    return message['params']['turn']
            await asyncio.wait_for(changed.wait(), 20)

    results = []
    try:
        await rpc('initialize', {'clientInfo': {'name': 'codex_ws_local_probe', 'version': '0.164.0'},
                                 'capabilities': {'experimentalApi': True}})
        proc.stdin.write(b'{"method":"initialized","params":{}}\n')
        started = await rpc('thread/start', {'ephemeral': True, 'cwd': str(home), 'approvalPolicy': 'never',
                                             'sandbox': 'read-only', 'baseInstructions': 'Use no tools. Local wire probe.'})
        thread = started['thread']['id']
        first = await rpc('turn/start', {'threadId': thread, 'input': [{'type': 'text', 'text': 'First local probe.'}]})
        turn = first['turn']['id']
        if controlled:
            await asyncio.wait_for(generated.wait(), 15)
            while not any(m.get('method') == 'item/agentMessage/delta' for m in notifications):
                changed.clear()
                await asyncio.wait_for(changed.wait(), 15)
            if steering:
                await rpc('turn/steer', {'threadId': thread, 'expectedTurnId': turn,
                                       'input': [{'type': 'text', 'text': 'Steered local probe.'}]})
            else:
                await rpc('turn/interrupt', {'threadId': thread, 'turnId': turn})
        results.append(await completed(turn))
        if name in ('continuation', 'cancel'):
            second = await rpc('turn/start', {'threadId': thread, 'input': [{'type': 'text', 'text': 'Second local probe.'}]})
            results.append(await completed(second['turn']['id']))
        assert all(x['status'] == ('interrupted' if i == 0 and name == 'cancel' else 'completed')
                   for i, x in enumerate(results)), results
        assert len(creates) == 2, len(creates)
        if steering:
            assert len(interrupts) == 1, interrupts
        if name == 'cancel':
            assert not interrupts and len(connections) == 2
        if name == 'retry_after':
            assert creates[1]['elapsed'] - creates[0]['elapsed'] >= 1
        for create in creates:
            assert 'instructions' not in create['body']
            assert create['body']['parallel_tool_calls'] is False
        summary = {'scenario': name, 'connections': len(connections), 'creates': len(creates),
                   'prewarms': len(prewarms),
                   'interrupts': interrupts, 'turn_statuses': [x['status'] for x in results],
                   'create_keys': [list(x['body']) for x in creates],
                   'previous_response_ids': [x['body'].get('previous_response_id') for x in creates],
                   'create_interval_seconds': creates[1]['elapsed'] - creates[0]['elapsed']}
        (folder / 'summary.json').write_text(json.dumps(summary, indent=2))
        print(json.dumps(summary), flush=True)
    finally:
        (folder / 'wire.json').write_text(json.dumps(records, indent=2))
        (folder / 'app-server.json').write_text(json.dumps(notifications, indent=2))
        proc.stdin.close()
        try:
            await asyncio.wait_for(proc.wait(), 5)
        except asyncio.TimeoutError:
            proc.terminate()
            await proc.wait()
        await reader_task
        stderr.close()
        server.close()
        await server.wait_closed()


async def main():
    for name in ['continuation']:
        await asyncio.wait_for(scenario(name), 60)


asyncio.run(main())
