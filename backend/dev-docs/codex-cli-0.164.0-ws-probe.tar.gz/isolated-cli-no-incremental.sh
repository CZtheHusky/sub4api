#!/bin/bash
set -eu
exec /usr/bin/bwrap --unshare-net --unshare-pid --unshare-ipc --unshare-uts --ro-bind / / --tmpfs /home --tmpfs /root --tmpfs /run --tmpfs /tmp --proc /proc --dev /dev --ro-bind /home/caozhe/.codex/packages/standalone/releases/0.164.0-x86_64-unknown-linux-musl/bin /tmp/cli --bind /tmp/codex164-alignment.ymc5RW /tmp/task --clearenv --setenv PATH /usr/bin:/bin --setenv HOME /tmp/home --chdir /tmp /usr/bin/python3 /tmp/task/cli-ws-no-incremental-probe.py
